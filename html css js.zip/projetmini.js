var men1 = document.getElementById("menu_itm1");
var men2 = document.getElementById("menu_itm2");
var men3 = document.getElementById("menu_itm3");
var men4 = document.getElementById("menu_itm4");
var men5 = document.getElementById("menu_itm5");
var men6 = document.getElementById("menu_itm6");
var men7 = document.getElementById("menu_itm7");
var men8 = document.getElementById("menu_itm8");
  function acc(){
    document.getElementById("iitem1").style.display = "none";
    document.getElementById("iitem2").style.display = "none";
    document.getElementById("iitem3").style.display = "none";
    document.getElementById("iitem4").style.display = "none";
    document.getElementById("iitem5").style.display = "none";
    document.getElementById("iitem6").style.display = "none";
    document.getElementById("iitem7").style.display = "none";
    document.getElementById("iitem8").style.display = "none";
    document.getElementById("para1").style.display = "none";
    document.getElementById("para2").style.display = "none";
    document.getElementById("para3").style.display = "none";
    document.getElementById("para4").style.display = "none";
    document.getElementById("match2").style.display="none";
    document.getElementById("classe").style.display = "none";
    document.getElementById("aquiqatar").style.display = "none";
    document.getElementById("aquiespagne").style.display = "none";
    document.getElementById("aquiAGLT").style.display = "none";
    document.getElementById("aquiMAROC").style.display = "none";
    document.getElementById("aquicco").style.display = "none";
    document.getElementById("aquibresil").style.display = "none";
    document.getElementById("aquiarg").style.display = "none";
    document.getElementById("aquAU").style.display = "none";
  }
men1.onclick = function () {
  document.getElementById("iitem1").style.display = "block";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
  document.getElementById("aquiespagne").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquAU").style.display = "none";
}
men2.onclick = function () {
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "block";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquAU").style.display = "none";
}

men3.onclick = function () {
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "block";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquAU").style.display = "none";
}
men4.onclick = function () {
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "block";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquAU").style.display = "none";
}
men5.onclick = function () {
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "block";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquAU").style.display = "none";
}
men6.onclick = function () {
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "block";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquAU").style.display = "none";
}
men7.onclick = function () {
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "block";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquAU").style.display = "none";
}
men8.onclick = function () {
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "block";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquAU").style.display = "none";
}
function fctt(){
  document.getElementById("match2").style.display="block";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("classe").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquAU").style.display = "none";
}
function afficher1() {
  document.getElementById("para1").style.display = "block";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquAU").style.display = "none";
}

function afficher2() {
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "block";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquAU").style.display = "none";
}

function afficher3() {
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "block";
  document.getElementById("para4").style.display = "none";
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquAU").style.display = "none";
}
function afficher4() {
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "block";
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquAU").style.display = "none";
}

function classement(){
  document.getElementById("classe").style.display = "block";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquAU").style.display = "none";
}

var togglemenu=document.querySelector('.reponsivemenu');
var menu=document.querySelector('.menu');
togglemenu.onclick=function(){
  togglemenu.classList.toggle('active');
}
const productContainers = [...document.querySelectorAll('.product-container')];
const nxtBtn = [...document.querySelectorAll('.nxt-btn')];
const preBtn = [...document.querySelectorAll('.pre-btn')];

productContainers.forEach((item, i) => {
    let containerDimensions = item.getBoundingClientRect();
    let containerWidth = containerDimensions.width;

    nxtBtn[i].addEventListener('click', () => {
        item.scrollLeft += containerWidth;
    })

    preBtn[i].addEventListener('click', () => {
        item.scrollLeft -= containerWidth;
    })
})

 function affiqatar(){
  document.getElementById("aquAU").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiqatar").style.display = "block";
  document.getElementById("aquiespagne").style.display ="none";
  document.getElementById("iitem1").style.display = "block";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
 }
 function espane(){
  document.getElementById("aquAU").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display ="block";
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "block";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
 }
 function equA(){
  document.getElementById("aquAU").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "block";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display ="none";
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "block";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
 }
 function equimaroc(){
  document.getElementById("aquAU").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "block";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display ="none";
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "block";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
 }
 function bresil(){
  document.getElementById("aquAU").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquibresil").style.display = "block";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display ="none";
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "block";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
 }
 function argen(){
  document.getElementById("aquAU").style.display = "none";
  document.getElementById("aquiarg").style.display = "block";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display ="none";
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "block";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
 }
 function core(){
  document.getElementById("aquAU").style.display = "none";
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquicco").style.display = "block";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display ="none";
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "none";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "block";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
 }
 function austa(){
  document.getElementById("aquiarg").style.display = "none";
  document.getElementById("aquibresil").style.display = "none";
  document.getElementById("aquicco").style.display = "none";
  document.getElementById("aquAU").style.display = "bLock";
  document.getElementById("aquiMAROC").style.display = "none";
  document.getElementById("aquiAGLT").style.display = "none";
  document.getElementById("aquiqatar").style.display = "none";
  document.getElementById("aquiespagne").style.display ="none";
  document.getElementById("iitem1").style.display = "none";
  document.getElementById("iitem2").style.display = "none";
  document.getElementById("iitem3").style.display = "none";
  document.getElementById("iitem4").style.display = "block";
  document.getElementById("iitem5").style.display = "none";
  document.getElementById("iitem6").style.display = "none";
  document.getElementById("iitem7").style.display = "none";
  document.getElementById("iitem8").style.display = "none";
  document.getElementById("para1").style.display = "none";
  document.getElementById("para2").style.display = "none";
  document.getElementById("para3").style.display = "none";
  document.getElementById("para4").style.display = "none";
  document.getElementById("match2").style.display="none";
  document.getElementById("classe").style.display = "none";
 }

 function ajouter(){
  var elt=document.createElement("tr");
  elt.class="lignes";
  document.getElementById("tb").appendChild(elt);
  var cases1=document.createElement("td");
  cases1.innerHTML=prompt("NOM:");
  elt.appendChild(cases1);

  var cases2=document.createElement("td");
  cases2.innerHTML=prompt("poste:");
  elt.appendChild(cases2);
  
  
  var cases3=document.createElement("td");
cases3.innerHTML=prompt("date de naissance:");
elt.appendChild(cases3);

var cases4=document.createElement("td");
var b=document.createElement("button");
b.type="button";
b.onclick=function(){
    this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);
}
b.innerHTML="DELET";
cases4.appendChild(b);
elt.appendChild(cases4);

  
  }






function ajouter1(){
    var elt=document.createElement("tr");
    elt.class="lignes";
    document.getElementById("tb1").appendChild(elt);
    var cases1=document.createElement("td");
    cases1.innerHTML=prompt("NOM:");
    elt.appendChild(cases1);
  
    var cases2=document.createElement("td");
    cases2.innerHTML=prompt("poste:");
    elt.appendChild(cases2);
    
    
    var cases3=document.createElement("td");
  cases3.innerHTML=prompt("date de naissance:");
  elt.appendChild(cases3);
  
  var cases4=document.createElement("td");
  var b=document.createElement("button");
  b.type="button";
  b.onclick=function(){
      this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);
  }
  b.innerHTML="DELET";
  cases4.appendChild(b);
  elt.appendChild(cases4);
  
    
    }





    function ajouter2(){
      var elt=document.createElement("tr");
      elt.class="lignes";
      document.getElementById("tb2").appendChild(elt);
      var cases1=document.createElement("td");
      cases1.innerHTML=prompt("NOM:");
      elt.appendChild(cases1);
    
      var cases2=document.createElement("td");
      cases2.innerHTML=prompt("poste:");
      elt.appendChild(cases2);
      
      
      var cases3=document.createElement("td");
    cases3.innerHTML=prompt("date de naissance:");
    elt.appendChild(cases3);
    
    var cases4=document.createElement("td");
    var b=document.createElement("button");
    b.type="button";
    b.onclick=function(){
        this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);
    }
    b.innerHTML="DELET";
    cases4.appendChild(b);
    elt.appendChild(cases4);
    
      
      }

      
    function ajouter3(){
      var elt=document.createElement("tr");
      elt.class="lignes";
      document.getElementById("tb3").appendChild(elt);
      var cases1=document.createElement("td");
      cases1.innerHTML=prompt("NOM:");
      elt.appendChild(cases1);
    
      var cases2=document.createElement("td");
      cases2.innerHTML=prompt("poste:");
      elt.appendChild(cases2);
      
      
      var cases3=document.createElement("td");
    cases3.innerHTML=prompt("date de naissance:");
    elt.appendChild(cases3);
    
    var cases4=document.createElement("td");
    var b=document.createElement("button");
    b.type="button";
    b.onclick=function(){
        this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);
    }
    b.innerHTML="DELET";
    cases4.appendChild(b);
    elt.appendChild(cases4);
    
      
      }
  
  



      function ajouter4(){
        var elt=document.createElement("tr");
        elt.class="lignes";
        document.getElementById("tb4").appendChild(elt);
        var cases1=document.createElement("td");
        cases1.innerHTML=prompt("NOM:");
        elt.appendChild(cases1);
      
        var cases2=document.createElement("td");
        cases2.innerHTML=prompt("poste:");
        elt.appendChild(cases2);
        
        
        var cases3=document.createElement("td");
      cases3.innerHTML=prompt("date de naissance:");
      elt.appendChild(cases3);
      
      var cases4=document.createElement("td");
      var b=document.createElement("button");
      b.type="button";
      b.onclick=function(){
          this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);
      }
      b.innerHTML="DELET";
      cases4.appendChild(b);
      elt.appendChild(cases4);
      
        
        }
    
    
        function ajouter5(){
          var elt=document.createElement("tr");
          elt.class="lignes";
          document.getElementById("tb5").appendChild(elt);
          var cases1=document.createElement("td");
          cases1.innerHTML=prompt("NOM:");
          elt.appendChild(cases1);
        
          var cases2=document.createElement("td");
          cases2.innerHTML=prompt("poste:");
          elt.appendChild(cases2);
          
          
          var cases3=document.createElement("td");
        cases3.innerHTML=prompt("date de naissance:");
        elt.appendChild(cases3);
        
        var cases4=document.createElement("td");
        var b=document.createElement("button");
        b.type="button";
        b.onclick=function(){
            this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);
        }
        b.innerHTML="DELET";
        cases4.appendChild(b);
        elt.appendChild(cases4);
        
          
          }
          function ajouter6(){
            var elt=document.createElement("tr");
            elt.class="lignes";
            document.getElementById("tb6").appendChild(elt);
            var cases1=document.createElement("td");
            cases1.innerHTML=prompt("NOM:");
            elt.appendChild(cases1);
          
            var cases2=document.createElement("td");
            cases2.innerHTML=prompt("poste:");
            elt.appendChild(cases2);
            
            
            var cases3=document.createElement("td");
          cases3.innerHTML=prompt("date de naissance:");
          elt.appendChild(cases3);
          
          var cases4=document.createElement("td");
          var b=document.createElement("button");
          b.type="button";
          b.onclick=function(){
              this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);
          }
          b.innerHTML="DELET";
          cases4.appendChild(b);
          elt.appendChild(cases4);
          
            
            }
            function ajouter7(){
              var elt=document.createElement("tr");
              elt.class="lignes";
              document.getElementById("tb7").appendChild(elt);
              var cases1=document.createElement("td");
              cases1.innerHTML=prompt("NOM:");
              elt.appendChild(cases1);
            
              var cases2=document.createElement("td");
              cases2.innerHTML=prompt("poste:");
              elt.appendChild(cases2);
              
              
              var cases3=document.createElement("td");
            cases3.innerHTML=prompt("date de naissance:");
            elt.appendChild(cases3);
            
            var cases4=document.createElement("td");
            var b=document.createElement("button");
            b.type="button";
            b.onclick=function(){
                this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);
            }
            b.innerHTML="DELET";
            cases4.appendChild(b);
            elt.appendChild(cases4);
            
              
              }
      
